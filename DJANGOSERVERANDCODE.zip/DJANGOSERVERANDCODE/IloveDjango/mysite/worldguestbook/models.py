from django.db import models

# Create your models here.

class GuestBookItem(models.Model):
    content=models.TextField() #content relates to a field in the table

    
