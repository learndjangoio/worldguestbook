from django.shortcuts import render #we'll use this with html front-ends later
from django.http import HttpResponse,HttpResponseRedirect
from .models import GuestBookItem



# Create your views here.
#each view is essentially a function! (starting with def)

def worldguestbookView(request):
	allguestbookitems=GuestBookItem.objects.all()
	return render(request, 'worldguestbook\worldguestbook.html',{'all_items':allguestbookitems})

	
def addMessage(request):
#create a new object all_items
	new_item=GuestBookItem(content=request.POST['content'])
#save
	new_item.save()
#re-direct the item to the main guestbook after completing the addition	
	return HttpResponseRedirect('/worldguestbook/')

def deleteMessage(request,GuestBookItem_id):
	item_to_delete=GuestBookItem.objects.get(id=GuestBookItem_id)
	item_to_delete.delete()
	return HttpResponseRedirect('/worldguestbook/')
	
	
def loginView(request):
    return render(request, 'worldguestbook\login.html')
	


