from django.apps import AppConfig


class WorldguestbookConfig(AppConfig):
    name = 'worldguestbook'
