"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
#let's first import the view we just created
from worldguestbook.views import worldguestbookView
from worldguestbook.views import loginView
from worldguestbook.views import addMessage
from worldguestbook.views import deleteMessage
#the above would also work!

#and we need to update the path (url and routes below too)
urlpatterns = [
    path('admin/', admin.site.urls),
    path('worldguestbook/',worldguestbookView),
    path('login/',loginView), #login refers to what the user will type in in the browser..'
	path('addMessage/',addMessage),
	path('deleteMessage/<int:GuestBookItem_id>/',deleteMessage),
    ]
